# PyMuPDFb

This wheel contains [MuPDF](https://mupdf.readthedocs.io/) shared libraries for
use by [PyMuPDF](https://pymupdf.readthedocs.io/).

This wheel is shared by PyMuPDF wheels that are specific to different Python
versions, significantly reducing the total size of a release.
