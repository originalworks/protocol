"""Compatibility helpers."""

__all__ = [
    "BICUBIC",
    "LANCZOS",
]

LANCZOS = 1
BICUBIC = 3
