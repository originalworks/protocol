```bash
pip install -r requirements.txt -t .
zip -r ddexGenerateISCC.zip .
```

